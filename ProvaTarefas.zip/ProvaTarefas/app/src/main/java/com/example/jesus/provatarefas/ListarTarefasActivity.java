package com.example.jesus.provatarefas;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import java.util.List;

import io.objectbox.Box;

public class ListarTarefasActivity extends AppCompatActivity {

    private long userId;
    private List<Tarefa> tarefaList;
    private Box<Usuario> contasBox;
    private Box<Tarefa> tarefaBox;
    private RecyclerView tarefasRecyclerView;
    private TarefasAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_tarefas);
        contasBox = ((App) getApplication()).getBoxStore().boxFor(Usuario.class);
        tarefaBox = ((App) getApplication()).getBoxStore().boxFor(Tarefa.class);
        tarefasRecyclerView = (RecyclerView) findViewById(R.id.rv_tarefas);
    }

    @Override
    protected void onResume() {
        super.onResume();
        SharedPreferences preferences = getSharedPreferences("reader.file", MODE_PRIVATE);
        userId = preferences.getLong("userId",userId);
        tarefaList = tarefaBox.query().equal(Tarefa_.donoId,userId).build().find();
        adapter = new TarefasAdapter(this,tarefaList,tarefaBox);
        tarefasRecyclerView.setAdapter(adapter);
        tarefasRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        tarefasRecyclerView.setHasFixedSize(true);
    }

    public void novaTarefa(View view) {
        startActivity(new Intent(this,CadastroTarefasActivity.class));
    }
}
