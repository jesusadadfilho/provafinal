package com.example.jesus.provatarefas;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

import io.objectbox.Box;
import io.objectbox.query.Query;

public class MainActivity extends AppCompatActivity {

    private Box<Usuario> contasBox;
    private EditText editUsuario;
    private EditText editSenha;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contasBox = ((App)getApplication()).getBoxStore().boxFor(Usuario.class);
        setupViews();
    }

    private void setupViews() {
        editUsuario = findViewById(R.id.editLogin);
        editSenha =findViewById(R.id.editSenha);
    }

    public void login(View view) {
        String usuario = editUsuario.getText().toString();
        String senha = editSenha.getText().toString();
        if(!editUsuario.getText().toString().equals("") && !editSenha.getText().toString().equals("")){
            Query query = contasBox.query().equal(Usuario_.usuario,usuario).equal(Usuario_.senha,senha).build();
            List<Usuario> result = query.find();
            if(result.size() > 0) {
                Intent intent = new Intent(this, ListarTarefasActivity.class);
                SharedPreferences preferences = getSharedPreferences("reader.file", MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putLong("userId", result.get(0).getId());
                editor.apply();
                finish();
                startActivity(intent);
            }else{
                Toast.makeText(this,"Usuario não encontrado",Toast.LENGTH_SHORT).show();
            }
        }

    }

    public void cadastro(View view) {
        Usuario usuario = new Usuario();
        if(!editUsuario.getText().toString().equals("") && !editSenha.getText().toString().equals("")){
            usuario.setUsuario(editUsuario.getText().toString());
            usuario.setSenha(editSenha.getText().toString());
            contasBox.put(usuario);
        }
    }
}
