package com.example.jesus.provatarefas;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

import io.objectbox.Box;

public class CadastroTarefasActivity extends AppCompatActivity {
    EditText tituloEdit, descEdit;
    TextView  editData;
    private Box<Tarefa> tarefasBox;
    private Box<Usuario> contasBox;
    private long userId;
    private RadioButton aFazer,fazendo,feito,cancelada;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_tarefas);
        tarefasBox = ((App)getApplication()).getBoxStore().boxFor(Tarefa.class);
        contasBox = ((App)getApplication()).getBoxStore().boxFor(Usuario.class);
        SharedPreferences preferences = getSharedPreferences("reader.file", MODE_PRIVATE);
        userId = preferences.getLong("userId",userId);
        setupViews();
    }

    private void setupViews() {
        tituloEdit = findViewById(R.id.editTitulo);
        descEdit = findViewById(R.id.editDesc);
        editData = findViewById(R.id.editData);
        aFazer = findViewById(R.id.aFazer);
        fazendo = findViewById(R.id.fazendo);
        feito = findViewById(R.id.feita);
        cancelada = findViewById(R.id.cancelada);
    }

    public void salvar(View view) {
        try{
            String titulo, desc, data, estado = null;
            titulo = tituloEdit.getText().toString();
            desc = descEdit.getText().toString();
            data = editData.getText().toString();
            if(aFazer.isChecked()){
                estado = "A fazer";
            }else if(fazendo.isChecked()){
                estado = "Fazendo";
            }else if(feito.isChecked()){
                estado = "feita";
            }else if (cancelada.isChecked()){
                estado = "cancelada";
            }
            Tarefa tarefa = new Tarefa();
            tarefa.setTitulo(titulo);
            tarefa.setDescricao(desc);
            tarefa.setDataLimite(data);
            tarefa.setEstado(estado);
            tarefa.getDono().setTarget(contasBox.get(userId));
            tarefasBox.put(tarefa);
            finish();

        }catch (IllegalArgumentException e){
            Toast.makeText(this,"preencha tudo" ,Toast.LENGTH_SHORT).show();
        }
    }

    public void savarData(View v) {
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);


        if(v == findViewById(R.id.dataBtn)){
            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            editData.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                        }
                    }, year, month, day);
            datePickerDialog.show();
        }
    }
}
