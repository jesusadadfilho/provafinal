package com.example.jesus.provatarefas;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import io.objectbox.Box;

/**
 * Created by jesus on 14/03/2018.
 */

public class TarefasAdapter extends RecyclerView.Adapter<TarefasAdapter.TarefasViewHolder>  {

    private Context context;
    private List<Tarefa> tarefaList;
    private Box<Tarefa> tarefaBox;

    public TarefasAdapter(Context context, List<Tarefa> tarefaList, Box<Tarefa> tarefaBox) {
        this.context = context;
        this.tarefaList = tarefaList;
        this.tarefaBox = tarefaBox;
    }

    @Override
    public TarefasViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        final LayoutInflater inflater = LayoutInflater.from(context);
        View linha = inflater.inflate(R.layout.activity_tarefa_item, parent, false);
        return new TarefasViewHolder(linha) ;
    }

    @Override
    public void onBindViewHolder(TarefasViewHolder holder, int position) {
        Tarefa tarefa = this.tarefaList.get(position);
        holder.desc.setText(tarefa.getDescricao());
        holder.estado.setText(tarefa.getEstado());
        holder.titulo.setText(tarefa.getTitulo());
        holder.data.setText(tarefa.getDataLimite());

    }

    @Override
    public int getItemCount() {
        return this.tarefaList.size();
    }

    public class TarefasViewHolder extends RecyclerView.ViewHolder{

        private TextView titulo,desc,estado,data;
        public TarefasViewHolder(View itemView) {
            super(itemView);
            titulo = itemView.findViewById(R.id.tituloItem);
            desc = itemView.findViewById(R.id.descItem);
            estado = itemView.findViewById(R.id.estadoItem);
            data = itemView.findViewById(R.id.dataItem);
        }
    }
    public void setTarefas(List<Tarefa> tarefasList) {
        this.tarefaList = tarefasList   ;
    }
}
