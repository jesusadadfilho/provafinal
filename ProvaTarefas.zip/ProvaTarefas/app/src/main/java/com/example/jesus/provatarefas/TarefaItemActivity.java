package com.example.jesus.provatarefas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class TarefaItemActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarefa_item);
    }
}
