package com.example.jesus.provatarefas;

import io.objectbox.annotation.Entity;
import io.objectbox.annotation.Id;
import io.objectbox.relation.ToMany;

/**
 * Created by jesus on 14/03/2018.
 */
@Entity
public class Usuario {
    @Id long id;
    String usuario, senha;
    public ToMany<Tarefa> tarefasToMany;

    public ToMany<Tarefa> getTarefasToMany() {
        return tarefasToMany;
    }

    public void setTarefasToMany(ToMany<Tarefa> tarefasToMany) {
        this.tarefasToMany = tarefasToMany;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
}
